package selfstudy;

import java.util.Arrays;

public class Notepad {

}

class Solution {
    public int solution(int n) {
        int answer = 0;
        for(int )
        return answer;
    }
}