package quiz06;

import java.util.Arrays;
import java.util.Scanner;

public class MainClass {
	
	public static void main(String[] args) {
		
		MyCart mc = new MyCart(1000);
		
		
		mc.add("tv");
		mc.add("com");
		mc.add("radio");
		
		
	}

}
