package quiz01;

public class Quiz21 { // 백준 4-6

}
