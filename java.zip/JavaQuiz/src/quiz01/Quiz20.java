package quiz01;

public class Quiz20 {
	
	//백준 4-3
	

}
