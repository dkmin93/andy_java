package quiz01;

public class Quiz23 { //백준 7-2

}
