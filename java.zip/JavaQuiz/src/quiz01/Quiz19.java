package quiz01;

public class Quiz19 {
	
	public static void main(String[] args) {
		
		// 백준 4-2
		
	}

}
