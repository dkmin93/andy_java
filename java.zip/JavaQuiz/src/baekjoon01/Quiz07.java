package baekjoon01;

import java.util.Scanner;

public class Quiz07 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		String id = scan.next();
		
		System.out.println( id + "??!" );
		
	}

}
