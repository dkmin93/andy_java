package day02;

public class OperatorEx04 {

	public static void main(String[] args) {
		
		int a = 6;
		int b = 5;
		
		a += 3; //a = a + 3; 같은표현
		b =+ 3; //b = 3; 주의하기
		
		System.out.println(a);
		System.out.println(b);
		
		a -= 4;
		a *= 10;
		a /= 3;
		a %= 2;
		
		System.out.println(a);
		
		
		
		
	}
}
