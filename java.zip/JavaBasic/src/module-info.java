/**
 * 
 */
/**
 * 
 */
module JavaBasic {
}