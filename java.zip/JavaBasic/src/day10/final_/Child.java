package day10.final_;

public class Child extends Parent {
	
	//public void method02() {}
	
}
