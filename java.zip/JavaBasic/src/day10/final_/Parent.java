package day10.final_;
//final이 class 앞에 붙으면 상속이 불가능해진다
public /*final*/ class Parent {
	
	public void method01() {}
	public final void method02() {} //final이 메서드 앞에 붙으면 상속은되어도 오버라이딩은 불가능하다
	
	
	
}
