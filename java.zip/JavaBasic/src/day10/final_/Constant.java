package day10.final_;

public class Constant {
	
	public static final double PI = 3.14; // 상수
	public static final int O2 = 32;
	public static final long EARTH_RADIUS = 6400L;
	
	
}
