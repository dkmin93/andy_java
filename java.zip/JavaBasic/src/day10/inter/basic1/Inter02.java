package day10.inter.basic1;

public interface Inter02 {
	
	int ABC = 123; //상수니까 대문자표기
	void method02();

}
