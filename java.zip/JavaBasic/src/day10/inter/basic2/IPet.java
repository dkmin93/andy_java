package day10.inter.basic2;

public interface IPet {

	void play();
}
