package day10.inter.basic2;

public abstract class Animal {

	public abstract void eat();
}
