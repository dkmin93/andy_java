package day10.inter.basic2;

public abstract class Fish {
	
	public abstract void swim();

}
