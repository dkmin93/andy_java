package day10.abstract_.bad;

public class Store {
	
	//추상 클래스를 쓰지 않는다면?
	public void melon() {
		System.out.println("가격설정은 지점에서 해야합니다");
	}
	
	public void orange() {
		System.out.println("가격설정은 지점에서 해야합니다");
	}
	
	public void grape() {
		System.out.println("가격설정은 지점에서 해야합니다");
	}
	
	public void apple() {
		System.out.println("가격설정은 지점에서 해야합니다");
	}
	
	
}
