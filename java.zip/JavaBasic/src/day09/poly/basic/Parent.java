package day09.poly.basic;

public class Parent {
	
	public void method01() {
		System.out.println("부모의 1번 메서드 실행");
	}
	
	public void method02() {
		System.out.println("부모의 2번 메서드 실행");
	}

}
