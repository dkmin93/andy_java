package day09.static_.singleton;

public class MainClass {
	
	public static void main(String[] args) {
		
		//new Singleton();
		
		Singleton s1 = Singleton.getInstance();
		Singleton s2 = Singleton.getInstance();
		Singleton s3 = Singleton.getInstance();
		
		System.out.println(s1 == s2 && s2 == s3);
		//s1 s2 s3 다 하나의 똑같은 객체다
		
		
	}
	
	

}
