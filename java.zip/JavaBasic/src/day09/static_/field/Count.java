package day09.static_.field;

public class Count {
	
	public int a; //일반 멤버변수
	public static int b; //정적 멤버변수. 기울임 효과가 적용된다
	

}
