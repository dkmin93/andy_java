package day07.inherit.good;

public class Employee extends Person {

	String department;
	
}
