package day07.inherit.good;

public class Teacher extends Person {
	
	String subject;

}
