package day07.inherit.bad;

public class Teacher {
	
	String name;
	int age;
	String subject;
	
	String info() {
		return "이름:" + name + "나이:" + age;
	}

}
