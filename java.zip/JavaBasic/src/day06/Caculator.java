package day06;

public class Caculator {
	int result =0;
	int add(int a) {
		result += a;
		return result;
	}

}
