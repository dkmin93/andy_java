package day06.abc;

public class melon {

}
