package day06.abc; // 최상단부에 패키지명이 들어가야만 함

public class apple {

}
