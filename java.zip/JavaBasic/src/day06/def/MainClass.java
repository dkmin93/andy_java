package day06.def;


import java.util.Scanner;

import day01.SystemOut;
//해당 패키지의 모든 클래스를 한번에 import하려면
import day06.abc.*;


public class MainClass {

	//Apple a = new Apple();
	
	//모든 클래스는 데이터타입이 될 수 있다? yes 
	
	//Melon m =  new Melon();

	Scanner scan = new Scanner(System.in);
	
	int i = 1;


}