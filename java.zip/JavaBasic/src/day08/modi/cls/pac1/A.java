package day08.modi.cls.pac1;

//클래스의 접근제한 public, default 밖에 없습니다
class A {

}
