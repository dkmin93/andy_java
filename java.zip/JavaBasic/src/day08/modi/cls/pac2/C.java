package day08.modi.cls.pac2;

import day08.modi.cls.pac1.*;

public class C {
	
	A a = new A(); //A가 default 이므로 패키지가 달라서 접근 불가능
	B b = new B(); //public는 패키지가 달라도 접근 가능

}
