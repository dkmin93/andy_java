package day08.modi.protec.pac2;

import day08.modi.protec.pac1.A;

public class C extends A {

	public C() {
//		A a = new A();
//		a.bool = true;
//		a.method();
		
		//상속을 받았을 땐 super로 접근 가능
		super.bool = true;
		super.method();
	
	
	}

}
